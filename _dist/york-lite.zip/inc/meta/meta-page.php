<?php
/**
 * Page post type metabox(s).
 *
 * @package York Lite
 * @version 1.0.0
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

if ( ! function_exists( 'york_metabox_page' ) ) :
	/**
	 * Create a standard 'page' post type metabox.
	 */
	function york_metabox_page() {

		$prefix = '_bean_';

		$meta_box = array(
			'id' => 'bean-meta-box-page',
			'title' => esc_html__( 'Page Settings', 'york-lite' ),
			'page' => 'page',
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(
				array(
					'name' => esc_html__( 'Entry Header', 'york-lite' ),
					'desc' => esc_html__( 'Add a header tagline to this page.', 'york-lite' ),
					'id' => $prefix . 'entry_header',
					'type' => 'textarea',
					'std' => '',
				),
			),
		);
		york_add_meta_box( $meta_box );
	}

	add_action( 'add_meta_boxes', 'york_metabox_page' );

endif;
