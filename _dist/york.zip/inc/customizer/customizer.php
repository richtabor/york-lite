<?php
/**
 * Theme Customizer functionality
 *
 * @package York
 * @version 1.0.0
 * @author  ThemeBeans <hello@themebeans.com>
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Add postMessage support for site title and description for the Customizer.
 *
 * @param WP_Customize_Manager $wp_customize the Customizer object.
 */
function york_customize_register( $wp_customize ) {

	/**
	 * Remove unnecessary controls.
	 */
	$wp_customize->remove_section( 'colors' );
	$wp_customize->remove_section( 'background_image' );
	$wp_customize->remove_control( 'site_logo_header_text' );
	$wp_customize->remove_control( 'background_color' );

	/**
	 * Add custom controls.
	 */
	require get_parent_theme_file_path( '/inc/customizer/custom-controls/content.php' );
	require get_parent_theme_file_path( '/inc/customizer/custom-controls/range.php' );

	/**
	 * Top-Level Customizer sections and panels.
	 */
	$wp_customize->add_panel( 'york_theme_options', array(
		'title' 						=> esc_html__( 'Theme Options', 'york' ),
		'description' 					=> esc_html__( 'Customize various options throughout the theme with the settings within this panel.', 'york' ),
		'priority' 					    => 30,
	) );

	/**
	 * Theme Customizer Sections.
	 * For more information on Theme Customizer settings and default sections:
	 *
	 * @see https://codex.wordpress.org/Class_Reference/WP_Customize_Manager/add_section
	 */

	/**
	 * Add the colors section.
	 */
	$wp_customize->add_section( 'york_pro_colors', array(
		'title'                 => esc_html__( 'Colors', 'york' ),
		'panel'                 => 'york_theme_options',
	) );

			$wp_customize->add_setting( 'york_background_color', array(
				'default'               => '#ffffff',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_background_color', array(
				'label'                 => esc_html__( 'Background', 'york' ),
				'section'               => 'york_pro_colors',
			) ) );

			$wp_customize->add_setting( 'body_typography_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'body_typography_color', array(
				'label'             => esc_html__( 'Text Color', 'york' ),
				'section'               => 'york_pro_colors',
			) ) );

			$wp_customize->add_setting( 'body_secondary_typography_color', array(
				'default'               => '#909090',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'body_secondary_typography_color', array(
				'label'             => esc_html__( 'Secondary Text Color', 'york' ),
				'section'               => 'york_pro_colors',
			) ) );

			$wp_customize->add_setting( 'header_typography_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'header_typography_color', array(
				'label'             => esc_html__( 'Header Color', 'york' ),
				'section'               => 'york_pro_colors',
			) ) );

			$wp_customize->add_setting( 'theme_accent_color', array(
				'default'               => '#ff5c5c',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'theme_accent_color', array(
				'label'             => esc_html__( 'Accent Color', 'york' ),
				'section'               => 'york_pro_colors',
			) ) );

	/**
	 * Add the header section.
	 */
	$wp_customize->add_section( 'york_pro_header', array(
		'title'                 => esc_html__( 'Header', 'york' ),
		'panel'                 => 'york_theme_options',
	) );

			$wp_customize->add_setting( 'york_sitetitle_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_sitetitle_color', array(
				'label'                 => esc_html__( 'Site Title', 'york' ),
				'section'               => 'york_pro_header',
			) ) );

			$wp_customize->add_setting( 'york_sitetitlehover_color', array(
				'default'               => '#ff5c5c',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_sitetitlehover_color', array(
				'label'                 => esc_html__( 'Site Title Hover', 'york' ),
				'section'               => 'york_pro_header',
			) ) );

			$wp_customize->add_setting( 'york_navigationicon_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_navigationicon_color', array(
				'label'                 => esc_html__( 'Navigation Icon', 'york' ),
				'section'               => 'york_pro_header',
			) ) );

			$wp_customize->add_setting( 'york_navigationiconhover_color', array(
				'default'               => '#ff5c5c',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_navigationiconhover_color', array(
				'label'                 => esc_html__( 'Navigation Icon Hover', 'york' ),
				'section'               => 'york_pro_header',
			) ) );

			$wp_customize->add_setting( 'york_sidebarsocial_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_sidebarsocial_color', array(
				'label'                 => esc_html__( 'Social Icons', 'york' ),
				'section'               => 'york_pro_header',
			) ) );

	/**
	 * Add the portfolio section.
	 */
	$wp_customize->add_section( 'york_pro_portfolio', array(
		'title' 						=> esc_html__( 'Portfolio', 'york' ),
		'panel'       					=> 'york_theme_options',
	) );

			$wp_customize->add_setting( 'portfolio_single_navigation', array(
				'default'               => true,
				'sanitize_callback'     => 'york_sanitize_number_intval',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( 'portfolio_single_navigation', array(
				'type'                  => 'checkbox',
				'label'                 => esc_html__( 'Portfolio Navigation', 'york' ),
				'description'           => esc_html__( 'Enable the "Next" project post-to-post navigation element on single portfolio pages.', 'york' ),
				'section'               => 'york_pro_portfolio',
			) );

			$wp_customize->add_setting( 'portfolio_posts_count', array(
				'default'           	=> '-1',
				'sanitize_callback' 	=> 'york_sanitize_number_intval',
			) );

			$wp_customize->add_control( 'portfolio_posts_count', array(
				'type' 				    => 'number',
				'label' 				=> esc_html__( 'Portfolio Count', 'york' ),
				'description' 			=> esc_html__( 'Set the number of posts to display on the portfolio template. Use "-1" to load them all.', 'york' ),
				'section'				=> 'york_pro_portfolio',
			) );

			$wp_customize->add_setting( 'york_overlay_color', array(
				'default'               => '#ffffff',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_overlay_color', array(
				'label'                 => esc_html__( 'Overlay', 'york' ),
				'section'               => 'york_pro_portfolio',
			) ) );

			$wp_customize->add_setting( 'york_overlay_text_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_overlay_text_color', array(
				'label'                 => esc_html__( 'Overlay Text', 'york' ),
				'section'               => 'york_pro_portfolio',
			) ) );

	/**
	 * Add the footer section.
	 */
	$wp_customize->add_section( 'york_theme_options_footer', array(
		'title' 						=> esc_html__( 'Footer', 'york' ),
		'panel'       					=> 'york_theme_options',
	) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_footertext_color', array(
				'label'                 => esc_html__( 'Footer Text', 'york' ),
				'section'               => 'york_theme_options_footer',
			) ) );

			$wp_customize->add_setting( 'york_footernav_a_color', array(
				'default'               => '#909090',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_footernav_a_color', array(
				'label'                 => esc_html__( 'Footer Link', 'york' ),
				'section'               => 'york_theme_options_footer',
			) ) );

			$wp_customize->add_setting( 'york_footertexthover_color', array(
				'default'               => '#ff5c5c',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_footertexthover_color', array(
				'label'                 => esc_html__( 'Footer Link Hover', 'york' ),
				'section'               => 'york_theme_options_footer',
			) ) );

			$wp_customize->add_setting( 'york_footersocial_color', array(
				'default'               => '#000000',
				'sanitize_callback'     => 'sanitize_hex_color',
				'transport'             => 'postMessage',
			) );

			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'york_footersocial_color', array(
				'label'                 => esc_html__( 'Social Icons', 'york' ),
				'section'               => 'york_theme_options_footer',
			) ) );

	/**
	 * JetPack Site Logo feaure support
	 * Check to see if JetPack Site Logo module is added.
	 * For more information on the JetPack site logo:
	 *
	 * @see http://jetpack.me/support/site-logo/
	 */
	if ( ! function_exists( 'jetpack_the_site_logo' ) ) {

		$wp_customize->add_setting( 'site_logo', array(
			'sanitize_callback'     => 'york_sanitize_image',
			'default'               => '',
		) );

		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'site_logo', array(
			  'label'                   => esc_html__( 'Logo', 'york' ),
			  'section'                 => 'title_tagline',
			  'settings'                => 'site_logo',
		) ) );

		$wp_customize->add_setting( 'site_logo_width', array(
			'default'               => '',
			'sanitize_callback'     => 'york_sanitize_nohtml',
		) );

		$wp_customize->add_control( 'site_logo_width', array(
			'type'              => 'text',
			'label'                 => esc_html__( 'Logo Retina Width', 'york' ),
			'description'           => esc_html__( 'This value should be equal to half of the logo image width (in px). For example, enter "50" for a logo that is 100px wide.', 'york' ),
			'section'               => 'title_tagline',
		) );

	} else {

		$wp_customize->add_setting( 'retina_logo', array(
			'default'               => false,
			'sanitize_callback'     => 'york_sanitize_checkbox',
		) );

		$wp_customize->add_control( 'retina_logo', array(
			'type'                  => 'checkbox',
			'label'                 => esc_html__( 'Enable retina logo', 'york' ),
			'description'           => '',
			'section'               => 'title_tagline',
		) );
	}

	/**
	 * Set transports for the Customizer.
	 */

	$wp_customize->get_setting( 'blogname' )->transport            		= 'postMessage';
	$wp_customize->get_setting( 'site_logo' )->transport 		   		= 'refresh';
}

add_action( 'customize_register', 'york_customize_register', 11 );

/**
 * Binds JS handlers to make the Customizer preview reload changes asynchronously.
 */
function york_customize_preview_js() {
	wp_enqueue_script( 'york-customize-preview', get_theme_file_uri( '/assets/js/admin/customize-preview.js' ), array( 'customize-preview' ), '1.0.0', true );
}
add_action( 'customize_preview_init', 'york_customize_preview_js' );
